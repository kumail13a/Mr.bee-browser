package com.bubble.browser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Draws translated text over the page. It never handles touches, so the page below stays scrollable. */
public class OverlayView extends View {

    private static class Item {
        Rect box;
        StaticLayout layout;
    }

    private final List<Item> items = new ArrayList<>();
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);

    public OverlayView(Context c) {
        super(c);
        bg.setColor(Color.WHITE);
        setClickable(false);
        setFocusable(false);
    }

    public void clear() {
        items.clear();
        invalidate();
    }

    public int count() {
        return items.size();
    }

    public void add(Rect r, String text, boolean rtl) {
        int pad = 6;
        Rect box = new Rect(r);
        box.inset(-pad, -pad);
        box.intersect(0, 0, Math.max(1, getWidth()), Math.max(1, getHeight()));
        if (box.width() < 16 || box.height() < 16) return;

        int innerW = box.width() - 8;
        int innerH = box.height() - 4;

        StaticLayout best = null;
        for (float size = Math.min(innerH, 80f); size >= 14f; size -= 2f) {
            TextPaint tp = newPaint(size);
            StaticLayout l = build(text, tp, innerW, rtl);
            best = l;
            if (l.getHeight() <= innerH) break;
        }
        if (best == null) return;

        Item it = new Item();
        it.box = box;
        it.layout = best;
        items.add(it);
        invalidate();
    }

    private TextPaint newPaint(float size) {
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.rgb(17, 17, 17));
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        tp.setTextSize(size);
        return tp;
    }

    private StaticLayout build(String text, TextPaint tp, int width, boolean rtl) {
        return StaticLayout.Builder.obtain(text, 0, text.length(), tp, Math.max(8, width))
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .setTextDirection(rtl ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR)
                .build();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        for (Item it : items) {
            canvas.save();
            canvas.clipRect(it.box);
            canvas.drawRoundRect(new RectF(it.box), 10f, 10f, bg);
            float top = it.box.top + (it.box.height() - it.layout.getHeight()) / 2f;
            canvas.translate(it.box.left + 4, top);
            it.layout.draw(canvas);
            canvas.restore();
        }
    }
}
