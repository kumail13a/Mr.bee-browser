package com.bubble.browser;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final String[][] SRC = {
            {"ياباني", "ja"}, {"كوري", "ko"}, {"صيني", "zh"}, {"إنجليزي", "en"}
    };
    private static final String[][] TGT = {
            {"العربية", "ar"}, {"English", "en"}, {"Français", "fr"}, {"Español", "es"},
            {"Türkçe", "tr"}, {"Indonesia", "id"}, {"Русский", "ru"}
    };

    private static class Block {
        final Rect rect;
        final String text;
        Block(Rect r, String t) { rect = r; text = t; }
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private WebView web;
    private OverlayView overlay;
    private EditText urlBar;
    private Spinner spSrc, spTgt;
    private CheckBox cbAuto;
    private TextView status;

    private TextRecognizer recognizer;
    private String recognizerLang;
    private Translator translator;
    private String translatorKey;

    private boolean busy = false;
    private int gen = 0;

    private final Runnable autoRun = new Runnable() {
        @Override
        public void run() {
            if (!cbAuto.isChecked()) return;
            if (busy) {
                ui.postDelayed(this, 500);
                return;
            }
            translateNow();
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("p", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setFitsSystemWindows(true);

        // Row 1: address bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), dp(2), dp(6), dp(2));
        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextSize(14);
        urlBar.setHint("اكتب رابط الموقع أو كلمة بحث");
        urlBar.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            go(urlBar.getText().toString());
            hideKeyboard();
            return true;
        });
        Button goBtn = new Button(this);
        goBtn.setText("اذهب");
        goBtn.setOnClickListener(v -> {
            go(urlBar.getText().toString());
            hideKeyboard();
        });
        bar.addView(urlBar, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(goBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Row 2: languages + auto
        LinearLayout langs = new LinearLayout(this);
        langs.setOrientation(LinearLayout.HORIZONTAL);
        langs.setGravity(Gravity.CENTER_VERTICAL);
        langs.setPadding(dp(6), 0, dp(6), 0);
        spSrc = new Spinner(this);
        spTgt = new Spinner(this);
        spSrc.setAdapter(adapterOf(SRC));
        spTgt.setAdapter(adapterOf(TGT));
        spSrc.setSelection(Math.min(prefs.getInt("src", 0), SRC.length - 1));
        spTgt.setSelection(Math.min(prefs.getInt("tgt", 0), TGT.length - 1));
        AdapterView.OnItemSelectedListener langListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                prefs.edit().putInt("src", spSrc.getSelectedItemPosition())
                        .putInt("tgt", spTgt.getSelectedItemPosition()).apply();
                gen++;
                overlay.clear();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        };
        spSrc.setOnItemSelectedListener(langListener);
        spTgt.setOnItemSelectedListener(langListener);
        TextView arrow = new TextView(this);
        arrow.setText("  ←  ");
        cbAuto = new CheckBox(this);
        cbAuto.setText("تلقائي");
        cbAuto.setChecked(prefs.getBoolean("auto", false));
        cbAuto.setOnCheckedChangeListener((b, checked) -> {
            prefs.edit().putBoolean("auto", checked).apply();
            if (checked) scheduleAuto();
        });
        langs.addView(spSrc, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        langs.addView(arrow);
        langs.addView(spTgt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        langs.addView(cbAuto);

        // Page area: web view with the translation overlay on top
        FrameLayout area = new FrameLayout(this);
        web = new WebView(this);
        overlay = new OverlayView(this);
        area.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        area.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Bottom row
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(dp(6), dp(2), dp(6), dp(2));
        Button trBtn = new Button(this);
        trBtn.setText("ترجم");
        trBtn.setOnClickListener(v -> translateNow());
        Button clearBtn = new Button(this);
        clearBtn.setText("مسح");
        clearBtn.setOnClickListener(v -> {
            gen++;
            overlay.clear();
            setStatus("");
        });
        status = new TextView(this);
        status.setTextSize(12);
        status.setPadding(dp(8), 0, dp(8), 0);
        bottom.addView(trBtn);
        bottom.addView(clearBtn);
        bottom.addView(status, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(bar);
        root.addView(langs);
        root.addView(area, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(bottom);
        setContentView(root);

        setupWebView();
        String last = prefs.getString("url", "https://www.google.com");
        web.loadUrl(last);
    }

    private ArrayAdapter<String> adapterOf(String[][] data) {
        List<String> names = new ArrayList<>();
        for (String[] d : data) names.add(d[0]);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, names);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String scheme = r.getUrl().getScheme();
                return !("http".equals(scheme) || "https".equals(scheme));
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                urlBar.setText(url);
                gen++;
                overlay.clear();
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                prefs.edit().putString("url", url).apply();
                scheduleAuto();
            }
        });
        web.setOnScrollChangeListener((v, x, y, ox, oy) -> {
            gen++;
            overlay.clear();
            scheduleAuto();
        });
    }

    private void scheduleAuto() {
        ui.removeCallbacks(autoRun);
        if (cbAuto.isChecked()) ui.postDelayed(autoRun, 1000);
    }

    private void go(String input) {
        String s = input.trim();
        if (s.isEmpty()) return;
        String u;
        if (s.matches("(?i)^https?://.*")) u = s;
        else if (s.contains(".") && !s.contains(" ")) u = "https://" + s;
        else u = "https://www.google.com/search?q=" + Uri.encode(s);
        web.loadUrl(u);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
        web.requestFocus();
    }

    private void setStatus(String t) {
        status.setText(t);
    }

    private String src() {
        return SRC[spSrc.getSelectedItemPosition()][1];
    }

    private String tgt() {
        return TGT[spTgt.getSelectedItemPosition()][1];
    }

    private boolean isRtl() {
        String t = tgt();
        return t.equals("ar") || t.equals("fa") || t.equals("he") || t.equals("ur");
    }

    private void done(String msg) {
        busy = false;
        setStatus(msg);
    }

    // ---- capture -> OCR -> translate -> overlay ----

    private void translateNow() {
        if (busy) return;
        busy = true;
        final int g = ++gen;
        overlay.clear();
        setStatus("جاري التقاط الشاشة…");
        ui.postDelayed(() -> capture(g), 150);
    }

    private void capture(final int g) {
        if (g != gen) {
            busy = false;
            return;
        }
        int w = web.getWidth();
        int h = web.getHeight();
        if (w <= 0 || h <= 0) {
            done("الصفحة غير جاهزة بعد.");
            return;
        }
        final Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        int[] loc = new int[2];
        web.getLocationInWindow(loc);
        Rect r = new Rect(loc[0], loc[1], loc[0] + w, loc[1] + h);
        try {
            PixelCopy.request(getWindow(), r, bmp, result -> {
                if (result == PixelCopy.SUCCESS) {
                    runOcr(bmp, g);
                } else {
                    fallbackCapture(bmp, g);
                }
            }, ui);
        } catch (Exception e) {
            fallbackCapture(bmp, g);
        }
    }

    private void fallbackCapture(Bitmap bmp, int g) {
        try {
            web.draw(new Canvas(bmp));
            runOcr(bmp, g);
        } catch (Exception e) {
            done("تعذّر التقاط الشاشة.");
        }
    }

    private TextRecognizer recognizerFor(String lang) {
        if (recognizer != null && lang.equals(recognizerLang)) return recognizer;
        if (recognizer != null) recognizer.close();
        switch (lang) {
            case "ja":
                recognizer = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
                break;
            case "ko":
                recognizer = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
                break;
            case "zh":
                recognizer = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
                break;
            default:
                recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        }
        recognizerLang = lang;
        return recognizer;
    }

    private Translator translatorFor(String from, String to) {
        String key = from + ">" + to;
        if (translator != null && key.equals(translatorKey)) return translator;
        if (translator != null) translator.close();
        translator = Translation.getClient(new TranslatorOptions.Builder()
                .setSourceLanguage(from)
                .setTargetLanguage(to)
                .build());
        translatorKey = key;
        return translator;
    }

    private static String clean(String t, boolean cjk) {
        return cjk ? t.replaceAll("\\s+", "") : t.replaceAll("\\s+", " ").trim();
    }

    private static boolean usable(String t) {
        if (t.length() < 2) return false;
        for (int i = 0; i < t.length(); i++) {
            if (Character.isLetterOrDigit(t.charAt(i))) return true;
        }
        return false;
    }

    private void runOcr(Bitmap bmp, final int g) {
        if (g != gen) {
            busy = false;
            return;
        }
        setStatus("قراءة النص…");
        final String from = src();
        final boolean cjk = !from.equals("en");
        recognizerFor(from).process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener(text -> {
                    List<Block> list = new ArrayList<>();
                    for (Text.TextBlock b : text.getTextBlocks()) {
                        Rect bb = b.getBoundingBox();
                        String t = clean(b.getText(), cjk);
                        if (bb != null && bb.width() >= 12 && bb.height() >= 12 && usable(t)) {
                            list.add(new Block(bb, t));
                        }
                    }
                    translateBlocks(list, from, g);
                })
                .addOnFailureListener(e -> done("فشلت القراءة: " + e.getMessage()));
    }

    private void translateBlocks(final List<Block> list, String from, final int g) {
        if (g != gen) {
            busy = false;
            return;
        }
        if (list.isEmpty()) {
            done("ما لقيت نصاً في الشاشة الحالية.");
            return;
        }
        final String to = tgt();
        if (from.equals(to)) {
            done("اللغتان متطابقتان.");
            return;
        }
        final Translator tr = translatorFor(from, to);
        setStatus("تحميل نموذج الترجمة (أول مرة فقط)…");
        tr.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> translateNext(tr, list, 0, g))
                .addOnFailureListener(e -> done("تعذّر تحميل نموذج الترجمة. تأكد من الاتصال بالإنترنت."));
    }

    private void translateNext(final Translator tr, final List<Block> list, final int i, final int g) {
        if (g != gen) {
            busy = false;
            return;
        }
        if (i >= list.size()) {
            done("تمت الترجمة.");
            return;
        }
        setStatus("ترجمة " + (i + 1) + " / " + list.size());
        final Block b = list.get(i);
        tr.translate(b.text)
                .addOnSuccessListener(out -> {
                    if (g == gen) overlay.add(b.rect, out, isRtl());
                    translateNext(tr, list, i + 1, g);
                })
                .addOnFailureListener(e -> translateNext(tr, list, i + 1, g));
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.close();
        if (translator != null) translator.close();
        web.destroy();
        super.onDestroy();
    }
}
